require('dotenv').config();
const { Client, GatewayIntentBits } = require('discord.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent // Aggiungi questo se vuoi leggere il contenuto dei messaggi
    ]
});

// Messaggi per diverse lingue
const messages = {
    it: {
        start: 'Il server di Minecraft è online! Puoi giocare.',
        stop: 'Il server Minecraft è spento. Non puoi giocare al momento.',
        maintenance: 'Il server Minecraft è in manutenzione. Tornerà presto online.',
    },
    en: {
        start: 'The Minecraft server is online! You can play.',
        stop: 'The Minecraft server is offline. You cannot play at the moment.',
        maintenance: 'The Minecraft server is under maintenance. It will be back online soon.',
    },
    fr: {
        start: 'Le serveur Minecraft est en ligne ! Vous pouvez jouer.',
        stop: 'Le serveur Minecraft est en panne. Vous ne pouvez pas jouer pour le moment.',
        maintenance: 'Le serveur Minecraft est en cours de maintenance. Il sera bientôt de nouveau en ligne.',
    },
    de: {
        start: 'Der Minecraft-Server ist online! Du kannst spielen.',
        stop: 'Der Minecraft-Server ist offline. Du kannst im Moment nicht spielen.',
        maintenance: 'Der Minecraft-Server wird gerade gewartet. Er wird bald wieder online sein.',
    },
    ru: {
        start: 'Сервер Minecraft находится в сети! Вы можете играть.',
        stop: 'Сервер Minecraft находится в автономном режиме. В данный момент вы не можете играть.',
        maintenance: 'Сервер Minecraft находится на техническом обслуживании. В ближайшее время он вернется в сеть.',
    },
};

// Comandi disponibili
const commands = ['<start>', '<stop>', '<maintenance>'];

client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    const args = message.content.split(' ');

    // Verifica se il comando è valido
    if (!commands.includes(args[0])) return;

    // Verifica la lingua, utilizza 'it' come predefinita
    const language = messages[args[1]] ? args[1] : 'it';

    switch (args[0]) {
        case '<start>':
            message.channel.send(messages[language].start);
            break;
        case '<stop>':
            message.channel.send(messages[language].stop);
            break;
        case '<maintenance>':
            message.channel.send(messages[language].maintenance);
            break;
        default:
            break;
    }
});

client.login(process.env.TOKEN);